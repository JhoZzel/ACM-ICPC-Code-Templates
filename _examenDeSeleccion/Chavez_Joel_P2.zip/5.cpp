#include<iostream>
#include<string>
using namespace std;


int main(){
    int n;
    string s,answer;
    getline(cin,s);
    if (s.find('U')>s.length() || s.find('N')>s.length() || s.find('I')>s.length() || s.find('O')>s.length()){
        // answer debe ser la repeticion de alguna de las letraas distintas q no aparecen en "s"
    }
    else{
        // -------
    }
    
    cout<<answer<<endl;
    return 0;
}